#include "logtread.h"

logTread::logTread(QObject *parent)
    : QObject{parent}
{

}
